Outsoftware - Jetpac - SAM Coupe

Original disk image: Jetpac (Mode_4).mgt
The disk image is preserved byte for byte from the supplied archive.
Keep the full MGT disk intact.

Outsoftware catalogue: https://outsoftware.it/games/jetpac-sam-coupe/
