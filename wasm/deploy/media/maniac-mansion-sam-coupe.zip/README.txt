Outsoftware - Maniac Mansion - SAM Coupe

Original disk image: Maniac_Mansion (Mode_3).mgt
The disk image is preserved byte for byte from the supplied archive.
Keep the full MGT disk intact.

Outsoftware catalogue: https://outsoftware.it/games/maniac-mansion-sam-coupe/
